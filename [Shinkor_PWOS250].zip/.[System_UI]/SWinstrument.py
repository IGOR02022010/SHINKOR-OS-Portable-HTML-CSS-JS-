import os

def list_files_to_file(output_filename=".$SYSTEM_DATA$.txt", root_dir="."):
    """
    Создает файл output_filename и записывает туда все названия файлов 
    в папке root_dir и всех подпапках в формате: 'путь/к/файлу'
    
    :param output_filename: имя выходного файла
    :param root_dir: корневая директория для обхода (по умолчанию - текущая папка)
    """
    file_paths = []
    
    # Обходим все файлы и папки рекурсивно
    for dirpath, dirnames, filenames in os.walk(root_dir):
        for filename in filenames:
            # Формируем относительный путь к файлу
            relative_path = os.path.relpath(os.path.join(dirpath, filename), root_dir)
            
            # Если файл находится в корневой папке, относительный путь будет просто именем файла
            # os.relpath для файла в корне вернет имя файла без пути
            file_paths.append(relative_path)

    # Записываем в файл в требуемом формате
    with open(output_filename, "w", encoding="utf-8") as f:
        for path in file_paths:
            # Экранируем одинарные кавычки внутри имени файла, если они есть
            safe_path = path.replace("'", "\\'")
            f.write(f"  '{safe_path}',\n")

if __name__ == "__main__":
    # Создаем файл 444.txt в текущей директории
    list_files_to_file(".$SYSTEM_DATA$.txt")
    print("Файл .$SYSTEM_DATA$.txt успешно создан!")
