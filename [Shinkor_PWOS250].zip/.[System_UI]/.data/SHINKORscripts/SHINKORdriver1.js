document.addEventListener('DOMContentLoaded', () => {
    const triggerBtn = document.getElementById('shinkormenu');
    const menuContainer = document.getElementById('startMenuContainer');

   
    let isMenuOpen = false;

    function toggleMenu() {
        isMenuOpen = !isMenuOpen;
        
        if (isMenuOpen) {
            menuContainer.style.display = 'block'; 
        } else {
            menuContainer.style.display = 'none'; 
        }
    }

    
    if (triggerBtn) {
        triggerBtn.addEventListener('click', (e) => {
            e.stopPropagation(); 
            toggleMenu();
        });
    }

    
    document.addEventListener('click', (e) => {
        
        if (isMenuOpen && !triggerBtn.contains(e.target) && !menuContainer.contains(e.target)) {
            isMenuOpen = false;
            menuContainer.style.display = 'none';
        }
    }, true); 
});