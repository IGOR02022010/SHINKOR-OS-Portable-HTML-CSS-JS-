const style = document.createElement('style');

style.textContent = `
  #keyboard-toggle {
    position: fixed;
    transition: border-color 0.2s ease, box-shadow 0.3s ease;
    top: -2px;
    left: 50%;
    transform: translateX(-50%);
    padding: 6px 38px;
    background: rgba(98,98,98, 0.5);
    color: white;
    box-shadow: 0 0 9px rgba(230,230, 230, 0.5);
    border: 1px solid #7A7A7A;
    border-radius: 2px;

  }
    #keyboard-toggle:hover {
		padding:8wpx 50px;
	    background: rgba(98,98,98, 0.6);
        border: 1px dashed #7A7A7A;
        top: -2px;
		box-shadow: 0 0 15px rgba(255, 255, 255, 0.5);
	}
  #keyboard-toggle:active {
	box-shadow: 0 0 18px rgba(255, 255, 255, 0.8);
	border:1px dotted #DADADA;
	transition: box-shadow 0.3s ease;  
	}
	
  #virtual-keyboard {
    display: none;
	backdrop-filter: blur(3px);
    position: fixed;
    border-radius: 4px;
    box-shadow: 0 0 8px rgba(255, 255, 255, 0.6);
    bottom: 42px;
    transition: border-color 0.3s ease, transform 8888899.9s ease, box-shadow 0.3s ease;
    right:2px;
	padding: 4px;
    justify-content: center;
    background: rgba(16,16,16, 0.7);
    max-width: 445px;
    height: -50%;
    border: 1px solid #929292;
    z-index: 99999;
  }


  #virtual-keyboard:hover {
  box-shadow: 0 0 16px rgba(255, 255, 255, 0.6);
  transition: box-shadow 0.3s ease;  
  }
  
  .keyboard-row {
    display: flex;
    justify-content: center;
    margin-bottom: 3px;
  }

  .key {
    margin: 1px;
    padding: 4px 4px;
    background: rgba(39,39,39, 0.6);
    border: 1px solid #161616;
    border-radius: 3px;
    color: #dadada;
    text-align: center;
	font-family: arial;
    flex: 0 1 auto;
    min-width: 20px;
    
 
    user-select: none;
  }
  .key:active {
	background: rgba(40,40,40, 0.5);
    border-top: 1px solid #E2FFC4;
    color: green;
	transform: scale(0.93); 
  }
  .key:hover {
    border-top: 1px solid green;
  }

  .key.wide {
    flex: 0 1 80px;
  }
`;
document.head.appendChild(style);


const toggleBtn = document.createElement('button');
toggleBtn.id = 'keyboard-toggle';
toggleBtn.textContent = ''; // Добавлен текст для кнопки переключения, чтобы она не была пустой
document.body.appendChild(toggleBtn);


const keyboardContainer = document.createElement('div');
keyboardContainer.id = 'virtual-keyboard';
document.body.appendChild(keyboardContainer);

// Состояние клавиатуры
let currentLang = 'en'; // 'en' или 'ru'
let isCaps = false;

// Раскладки клавиатуры без лишних символов
const layouts = {
  en: [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '='],
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'"],
    ['z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/'],
    ['caps', 'lang', 'space', 'backspace']
  ],
  ru: [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '='],
    ['й', 'ц', 'у', 'к', 'е', 'н', 'г', 'ш', 'щ', 'з', 'х', 'ъ'],
    ['ё', 'ф', 'ы', 'в', 'а', 'п', 'р', 'о', 'л', 'д', 'ж', 'э'],
    ['я', 'ч', 'с', 'м', 'и', 'т', 'ь', 'б', 'ю', '.'],
    ['caps', 'lang', 'space', 'backspace']
  ]
};

function createKeyboard() {
  keyboardContainer.innerHTML = '';
  const currentLayout = layouts[currentLang];

  currentLayout.forEach(row => {
    const rowDiv = document.createElement('div');
    rowDiv.className = 'keyboard-row';

    row.forEach(key => {
      const keyElement = document.createElement('div');
      
      // Настройка класса wide для длинных кнопок
      const isWide = ['space', 'backspace', 'caps', 'lang'].includes(key);
      keyElement.className = `key ${isWide ? 'wide' : ''}`;
      
      // Отображение текста на кнопках
      if (key === 'space') {
        keyElement.textContent = '|____|';
      } else if (key === 'backspace') {
        keyElement.textContent = '<-BS-';
      } else if (key === 'caps') {
        keyElement.textContent = isCaps ? 'CAPS' : 'Caps';
      } else if (key === 'lang') {
        keyElement.textContent = currentLang.toUpperCase();
      } else {
        keyElement.textContent = isCaps ? key.toUpperCase() : key.toLowerCase();
      }

      keyElement.dataset.value = key;
      keyElement.addEventListener('click', handleKeyClick);
      rowDiv.appendChild(keyElement);
    });

    keyboardContainer.appendChild(rowDiv);
  });
}

function handleKeyClick() {
  const keyValue = this.dataset.value;

  if (keyValue === 'space') {
    document.execCommand('insertText', false, ' ');
  } else if (keyValue === 'backspace') {
    document.execCommand('delete');
  } else if (keyValue === 'caps') {
    isCaps = !isCaps;
    createKeyboard(); // Перерисовываем, чтобы обновить регистр букв
  } else if (keyValue === 'lang') {
    currentLang = currentLang === 'en' ? 'ru' : 'en';
    createKeyboard(); // Перерисовываем для смены языка
  } else {
    // В зависимости от состояния caps отправляем заглавную или строчную букву
    const char = isCaps ? keyValue.toUpperCase() : keyValue.toLowerCase();
    document.execCommand('insertText', false, char);
  }
}

toggleBtn.addEventListener('click', function() {
  if (keyboardContainer.style.display === 'none' || !keyboardContainer.style.display) {
    createKeyboard(); // Пересоздаем при каждом открытии, чтобы подтянуть актуальное состояние
    keyboardContainer.style.display = 'block';
  } else {
    keyboardContainer.style.display = 'none';
  }
});








