const style = document.createElement('style');

style.textContent = `
  #keyboard-toggle {
    position: fixed;
    transition: border-color 0.3s ease, transform 8888899.9s ease, box-shadow 0.5s ease;
    top: -2px;
    left: 50%;
    transform: translateX(-50%);
    padding: 6px 38px;
    background: rgba(98,98,98, 0.5);
    color: white;
    box-shadow: 0 0 3px rgba(230,230, 230, 0.2);
    border: 1px solid #7A7A7A;
    border-radius: 2px;

  }
    #keyboard-toggle:hover {
		padding:8wpx 50px;
		transition: box-shadow 0.8s ease;
	    background: rgba(98,98,98, 0.6);
        border: 1px dashed #7A7A7A;
		box-shadow: 0 0 5px rgba(12, 12, 12, 0.3);
	}
  #keyboard-toggle:active {
    transition: box-shadow 0.6s ease;
	box-shadow: 0 0 7px rgba(122, 122, 122, 0.8);
	border:1px dotted #DADADA;
	}
	
  #virtual-keyboard {
    display: none;
	backdrop-filter: blur(3px);
    position: fixed;
    border-radius: 2px;
    box-shadow: 0 0 8px rgba(12, 12, 12, 0.7);
    bottom: 0;
    transition: border-color 0.3s ease, transform 8888899.9s ease, box-shadow 0.5s ease;
    right:1px;
	padding: 4px;
    justify-content: center;
    background: rgba(16,16,16, 0.7);
    max-width: 445px;
    height: -50%;
    border: 1px solid #929292;
    z-index: 9999;
  }


  #virtual-keyboard:hover {
  box-shadow: 0 0 11px rgba(12, 12, 12, 0.7);
  transition: box-shadow 0.8s ease;  
  }
  
  .keyboard-row {
    display: flex;
    justify-content: center;
    margin-bottom: 3px;
  }

  .key {
    margin: 1px;
    padding: 4px 4px;
    background: rgba(39,39,39, 0.6);
    border: 1px solid #161616;
    border-radius: 3px;
    color: #dadada;
    text-align: center;
	font-family: arial;
    flex: 0 1 auto;
    min-width: 20px;
    
 
    user-select: none;
  }
  .key:active {
	background: rgba(40,40,40, 0.5);
    border-top: 1px solid #E2FFC4;
    color: green;
	transform: scale(0.93); 
  }
  .key:hover {
    border-top: 1px solid green;
  }

  .key.wide {
    flex: 0 1 80px;
  }
`;
document.head.appendChild(style);


const toggleBtn = document.createElement('button');
toggleBtn.id = 'keyboard-toggle';
toggleBtn.textContent = ''; // Добавлен текст для кнопки переключения, чтобы она не была пустой
document.body.appendChild(toggleBtn);


const keyboardContainer = document.createElement('div');
keyboardContainer.id = 'virtual-keyboard';
document.body.appendChild(keyboardContainer);

// Состояние клавиатуры
let currentLang = 'en'; // 'en' или 'ru'
let isCaps = false;

// Раскладки клавиатуры без лишних символов
const layouts = {
  en: [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '='],
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'"],
    ['z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/'],
    ['caps', 'lang', 'space', 'backspace']
  ],
  ru: [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '='],
    ['й', 'ц', 'у', 'к', 'е', 'н', 'г', 'ш', 'щ', 'з', 'х', 'ъ'],
    ['ф', 'ы', 'в', 'а', 'п', 'р', 'о', 'л', 'д', 'ж', 'э'],
    ['я', 'ч', 'с', 'м', 'и', 'т', 'ь', 'б', 'ю', '.'],
    ['caps', 'lang', 'space', 'backspace']
  ]
};

function createKeyboard() {
  keyboardContainer.innerHTML = '';
  const currentLayout = layouts[currentLang];

  currentLayout.forEach(row => {
    const rowDiv = document.createElement('div');
    rowDiv.className = 'keyboard-row';

    row.forEach(key => {
      const keyElement = document.createElement('div');
      
      // Настройка класса wide для длинных кнопок
      const isWide = ['space', 'backspace', 'caps', 'lang'].includes(key);
      keyElement.className = `key ${isWide ? 'wide' : ''}`;
      
      // Отображение текста на кнопках
      if (key === 'space') {
        keyElement.textContent = '|____|';
      } else if (key === 'backspace') {
        keyElement.textContent = '<-BS-';
      } else if (key === 'caps') {
        keyElement.textContent = isCaps ? 'CAPS' : 'Caps';
      } else if (key === 'lang') {
        keyElement.textContent = currentLang.toUpperCase();
      } else {
        keyElement.textContent = isCaps ? key.toUpperCase() : key.toLowerCase();
      }

      keyElement.dataset.value = key;
      keyElement.addEventListener('click', handleKeyClick);
      rowDiv.appendChild(keyElement);
    });

    keyboardContainer.appendChild(rowDiv);
  });
}

function handleKeyClick() {
  const keyValue = this.dataset.value;

  if (keyValue === 'space') {
    document.execCommand('insertText', false, ' ');
  } else if (keyValue === 'backspace') {
    document.execCommand('delete');
  } else if (keyValue === 'caps') {
    isCaps = !isCaps;
    createKeyboard(); // Перерисовываем, чтобы обновить регистр букв
  } else if (keyValue === 'lang') {
    currentLang = currentLang === 'en' ? 'ru' : 'en';
    createKeyboard(); // Перерисовываем для смены языка
  } else {
    // В зависимости от состояния caps отправляем заглавную или строчную букву
    const char = isCaps ? keyValue.toUpperCase() : keyValue.toLowerCase();
    document.execCommand('insertText', false, char);
  }
}

toggleBtn.addEventListener('click', function() {
  if (keyboardContainer.style.display === 'none' || !keyboardContainer.style.display) {
    createKeyboard(); // Пересоздаем при каждом открытии, чтобы подтянуть актуальное состояние
    keyboardContainer.style.display = 'block';
  } else {
    keyboardContainer.style.display = 'none';
  }
});







(function() {

  const widget = document.createElement('div');
  widget.id = 'net-status-widget';
  widget.className = 'shinkor-net-status checking';
  widget.title = 'Статус сети: проверка...';
  

  const textSpan = document.createElement('span');
  textSpan.className = 'status-text';
  textSpan.textContent = 'INTERNET';
  widget.appendChild(textSpan);
  
  document.body.appendChild(widget);


  const styleSheet = document.createElement('style');
  styleSheet.textContent = `
    .shinkor-net-status {
      position: fixed;
      top: 10px;
      right: 26%;
      width: 49px;
      height: 25px;
      border-radius: 3px;
      background: rgba(0, 0, 0, 6.5);
      font-size: 10px;
      white-space: nowrap;
      backdrop-filter: blur(6px);
      -webkit-backdrop-filter: blur(6px);
      border: 1px solid black;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background-color 0.3s, box-shadow 0.3s;
      pointer-events: none;
      user-select: none;
      overflow: hidden;
    }


    .status-text {

      font-size: 10px;
	  font-family: monospace;
      line-height: 1;
    }

  
    .shinkor-net-status.checking .status-text {
      animation: spin 1s linear infinite;
    }

  
    .shinkor-net-status.online {
      background-color: rgba(0, 0, 0, 0.7);
	  color: #00ffb1;
      border: 1px solid rgba(233,233,233,0.3);

    }
    
    .shinkor-net-status.offline {
      background-color: rgba(0, 0, 0, 0.7); 
	  color: #ff549a;
      border: 1px solid rgba(233,233,233,0.3);
    }

    .shinkor-net-status.checking {
      background-color: rgba(0, 0, 0, 0.7);
	  color: #ffff00;
      border: 1px solid rgba(233,233,233,0.3);
    }


  `;
  document.head.appendChild(styleSheet);

  let isChecking = false;

  const setStatus = (status) => {

    widget.classList.remove('online', 'offline', 'checking');

    widget.classList.add(status);
    
    if (status === 'online') widget.title = 'Статус сети: онлайн';
    if (status === 'offline') widget.title = 'Статус сети: офлайн';
    if (status === 'checking') widget.title = 'Статус сети: проверка...';
  };

  const verifyNetwork = async () => {
    if (isChecking) return;
    isChecking = true;
    setStatus('checking');

    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        isChecking = false;
        setStatus('online');
        resolve(true);
      };
      img.onerror = () => {
        isChecking = false;
        setStatus('offline');
        resolve(false);
      };
     
   
      img.src = 'https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png?' + new Date().getTime();

 
      setTimeout(() => {
        if (!img.complete) {
          isChecking = false;
          setStatus('offline');
          resolve(false);
        }
      }, 5000);
    });
  };

  const handleBrowserEvent = () => {
    if (navigator.onLine) {
      verifyNetwork();
    } else {
      setStatus('offline');
    }
  };

  window.addEventListener('online', handleBrowserEvent);
  window.addEventListener('offline', handleBrowserEvent);

  handleBrowserEvent();


  setInterval(() => {
    if (widget.classList.contains('online')) {
      verifyNetwork();
    }
  }, 60000); 
})();
