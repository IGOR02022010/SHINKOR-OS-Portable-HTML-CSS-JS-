﻿
(function() {
  const Widgets = {
    platform: {
      element: null,
      init: function() {
        const platformInfo = document.createElement('div');
        Object.assign(platformInfo.style, {
          position: 'fixed',
          bottom: '6px',
          right: '140px', // Фиксированное расстояние от правого края
          background: 'rgba(0, 0, 0, 0.4)',
          borderTop: '2px solid #929292',
          borderLeft: '1px solid #656565',
          borderRight: '1px solid #656565',
		  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.4)',
          borderBottom: '1px solid #505050',
          color: '#d7d7d7',
          padding: '6px 12px',
          borderRadius: '4px',
          fontSize: '11px',
          fontFamily: 'monospace',
          whiteSpace: 'nowrap'

        });

        const userAgent = navigator.userAgent;
        let platformName = 'OS';

        if (/Windows/i.test(userAgent)) {
          platformName = 'WIN-32';
        } else if (/Mac/i.test(userAgent)) {
          platformName = 'MAC';
        } else if (/Linux/i.test(userAgent)) {
          platformName = 'LINUX';
        } else if (/Android/i.test(userAgent)) {
          platformName = 'ANDROID';
        } else if (/iPad/i.test(userAgent)) {
          platformName = 'IPAD';
        } else if (/iOS/i.test(userAgent)) {
          platformName = 'IOS';
        } else if (/iPhone/i.test(userAgent)) {
          platformName = 'IPHONE';
        }

        platformInfo.textContent = `${platformName}`;
        this.element = platformInfo;
        document.body.appendChild(this.element);

        // Убрали обработчик resize — он больше не нужен
      }
    },

    keyboardLayout: {
      element: null,
      styleElement: null,
      lastLayout: 'Unknown',

      init: function() {
        const layoutElement = document.createElement('div');
        layoutElement.id = 'keyboard-layout';
        layoutElement.dataset.lang = 'Unknown';
        layoutElement.textContent = 'EN';
        this.element = layoutElement;

        const style = document.createElement('style');
        style.textContent = `
          #keyboard-layout {
            position: fixed;
            bottom: 7px;
            right: 100px; /* Фиксированное расстояние — между platform и keyboardLayout будет ~35px */
            background: rgba(0, 0, 0, 0.4);
            color: #d8d8d8;
            padding: 6px 3px;
			box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
            border-radius: 4px;
            font-family: monospace;
            font-size: 10px;
            min-width: 25px;
            text-align: center;
            border-top: 2px solid #929292;
            border-left: 1px solid #656565;
            border-right: 1px solid #656565;
            border-bottom: 1px solid #505050;
            transition: color 0.2s, border-color 0.2s;

          }
        `;
        this.styleElement = style;
        document.head.appendChild(this.styleElement);
        document.body.appendChild(this.element);

        this.bindEvents();
        this.updateDisplay('Unknown');
      },

      getLayoutByChar: function(char) {
        if (!char || char.length !== 1) return 'Unknown';
        const code = char.charCodeAt(0);

        if ((code >= 65 && code <= 90) || (code >= 97 && code <= 122)) return 'EN';
        if ((code >= 1040 && code <= 1103) || code === 1025 || code === 1105) return 'RU';
        if (code >= 1536 && code <= 1791) return 'AR';
        if ((code >= 12352 && code <= 12447) || (code >= 12448 && code <= 12543)) return 'JA';
        if (code >= 44032 && code <= 55203) return 'KO';
        if (code >= 19968 && code <= 40959) return 'CN';

        return 'Unknown';
      },

      updateDisplay: function(layout) {
        if (layout === this.lastLayout) return;
        this.lastLayout = layout;
        this.element.textContent = layout === 'Unknown' ? 'EN' : layout;
        this.element.dataset.lang = layout;
      },

      bindEvents: function() {
        document.addEventListener('input', (event) => {
          const target = event.target;
          if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
            const value = target.value;
            if (value && value.length > 0) {
              const lastChar = value.slice(-1);
              const layout = this.getLayoutByChar(lastChar);
              this.updateDisplay(layout);
            }
          }
        }, true);

        document.addEventListener('keydown', (event) => {
          let layout = 'Unknown';
          let key = event.key;

          if (key.startsWith('Key') && key.length > 3) {
            key = key.substring(3).toLowerCase();
            if (key.length === 1) {
              layout = this.getLayoutByChar(key);
            }
          } else if (key.length === 1 && !key.startsWith('Control') && !key.startsWith('Alt')) {
            layout = this.getLayoutByChar(key);
          }

          if (layout !== 'Unknown') {
            this.updateDisplay(layout);
          }
        });
      }
    },

    networkStatus: {
      element: null,
      styleElement: null,
      isChecking: false,

      init: function() {
        const widget = document.createElement('div');
        widget.id = 'net-status-widget';
        widget.className = 'shinkor-net-status checking';
        widget.title = 'Статус сети: проверка...';

        const textSpan = document.createElement('span');
        textSpan.className = 'status-text';
        textSpan.textContent = 'INTERNET';
        widget.appendChild(textSpan);
        this.element = widget;

        const styleSheet = document.createElement('style');
        styleSheet.textContent = `
          .shinkor-net-status {
            position: fixed;
            bottom: 8px;
            right: 217px; /* Самый правый виджет */
            width: 49px;
            height: 25px;
            border-radius: 3px;
            background: rgba(0, 0, 0, 0.4);
            font-size: 10px;
            white-space: nowrap;
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            border-top: 2px solid #929292;
            border-left: 1px solid #656565;
            border-right: 1px solid #656565;
            border-bottom: 1px solid #505050;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s, box-shadow 0.3s;
            pointer-events: none;
            user-select: none;
            overflow: hidden;

          }

          .status-text {
            font-size: 10px;
            font-family: monospace;
            line-height: 1;
          }

          .shinkor-net-status.checking .status-text {
            animation: spin 1s linear infinite;
          }

          @keyframes spin {
            0% { transform: rotate(0deg); }

          }

          .shinkor-net-status.online {
            background-color: rgba(0, 0, 0, 0.4);
            color: #00ffb1;
          }

          .shinkor-net-status.offline {
            background-color: rgba(0, 0, 0, 0.4); 
            color: #ff549a;
          }

          .shinkor-net-status.checking {
            background-color: rgba(0, 0, 0, 0.4);
            color: #ffff00;
          }
        `;
        this.styleElement = styleSheet;
        document.head.appendChild(this.styleElement);
        document.body.appendChild(this.element);

        this.bindEvents();
      },

      setStatus: function(status) {
        this.element.classList.remove('online', 'offline', 'checking');
        this.element.classList.add(status);

        if (status === 'online') this.element.title = 'Статус сети: онлайн';
        if (status === 'offline') this.element.title = 'Статус сети: офлайн';
        if (status === 'checking') this.element.title = 'Статус сети: проверка...';
      },

      verifyNetwork: function() {
        return new Promise((resolve) => {
          if (this.isChecking) {
            resolve(false);
            return;
          }
          this.isChecking = true;
          this.setStatus('checking');

          const img = new Image();
          img.onload = () => {
            this.isChecking = false;
            this.setStatus('online');
            resolve(true);
          };
          img.onerror = () => {
            this.isChecking = false;
            this.setStatus('offline');
            resolve(false);
          };

          img.src = 'https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png?' + new Date().getTime();

          setTimeout(() => {
            if (!img.complete) {
              this.isChecking = false;
              this.setStatus('offline');
              resolve(false);
            }
          }, 5000);
        });
      },

      handleBrowserEvent: function() {
        if (navigator.onLine) {
          this.verifyNetwork();
        } else {
          this.setStatus('offline');
        }
      },

      bindEvents: function() {
        window.addEventListener('online', () => this.handleBrowserEvent());
        window.addEventListener('offline', () => this.handleBrowserEvent());

        this.handleBrowserEvent();

        setInterval(() => {
          if (this.element.classList.contains('online')) {
            this.verifyNetwork();
          }
        }, 20000);
      }
    }
  };

  // Инициализация всех виджетов
  Widgets.platform.init();
  Widgets.keyboardLayout.init();
  Widgets.networkStatus.init();
})();

