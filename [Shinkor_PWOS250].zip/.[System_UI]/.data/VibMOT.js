const clickButton = document.getElementById('VIBclickButton');
function vibrate() {
    if (navigator.vibrate) { 
        navigator.vibrate(50); 
    } else {
        console.log('ERROR: Vibrasia ne rabotaet na etom ustroistve.');
    }
}