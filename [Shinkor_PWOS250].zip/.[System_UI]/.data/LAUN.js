(function () {
  // --- Утилиты для localStorage ---
  function loadValue(key, fallback) {
    var v = parseFloat(localStorage.getItem(key));
    return isNaN(v) ? fallback : v;
  }

  function saveValue(key, val) {
    localStorage.setItem(key, String(val));
  }

  // --- Создание оверлея для яркости ---
  var brightnessOverlay = null;

  function createBrightnessOverlay() {
    if (brightnessOverlay) return brightnessOverlay;

    brightnessOverlay = document.createElement('div');
    brightnessOverlay.id = 'brightness-overlay';
    brightnessOverlay.style.cssText = [
      'position: fixed;',
      'top: 0; left: 0; width: 100%; height: 100%;',
      'background-color: rgba(3, 0, 0, 0);',
      'pointer-events: none;',
      'z-index: 999999999999999;',
      'transition: background-color 0.3s ease;',
      'margin: 0; padding: 0;'
    ].join('');

    document.body.appendChild(brightnessOverlay);
    return brightnessOverlay;
  }

  function applyBrightness(brightness) {
    // brightness: 0..100
    // 0% -> alpha 0 (светло), 100% -> alpha 0.8 (темно)
    var alpha = (brightness / 100) * 0.8;
    var overlay = createBrightnessOverlay();
    overlay.style.backgroundColor = 'rgba(4, 0, 0, ' + alpha.toFixed(3) + ')';
  }

  // --- Громкость через Web Audio API ---
  var audioCtx = null;
  var masterGain = null;

  function getAudioCtx() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      masterGain = audioCtx.createGain();
      masterGain.connect(audioCtx.destination);
    }
    return audioCtx;
  }

  function applyVolume(volume) {
    getAudioCtx();
    masterGain.gain.value = volume / 100;

    document.querySelectorAll('audio, video').forEach(function (el) {
      if (!el._alisaRouted) {
        try {
          var src = audioCtx.createMediaElementSource(el);
          src.connect(masterGain);
          el._alisaRouted = true;
        } catch (e) {
          // уже подключён или недоступен
        }
      }
    });
  }

  // --- Слайдер-попап над кнопкой ---
  function createSliderPopup(btn, opts) {
    var popup = document.createElement('div');
    popup.style.cssText = [
      'position: absolute',
      'bottom: 100%',
      'left: 50%',
      'transform: translateX(-50%)',
      'margin-bottom: 7px',
      'background: rgba(40, 40, 56, 0.7)',
      'border: 1px solid #929292',
      'border-radius: 6px',
      'padding: 10px',
      'display: none',
      'z-index: 999',
      'box-shadow: 0 4px 12px rgba(0,0,0,0.4)'
    ].join(';');

    var slider = document.createElement('input');
    slider.type = 'range';
    slider.min = opts.min;
    slider.max = opts.max;
    slider.value = opts.value;
    slider.style.cssText = [
      'writing-mode: bt-lr',
      '-webkit-appearance: slider-vertical',
      'width: 34px',
      'height: 120px',
      'display: block',
      'background: #e0e0e0',         
      'border-radius: 10px',         
      'outline: none',               
      'margin: 0 auto'
    ].join(';');

    var label = document.createElement('div');
    label.style.cssText = 'color:#f0f0f0;font-size:11px;text-align:center;margin-top:4px;font-family:arial';
    label.textContent = opts.value + (opts.unit || '');

    popup.appendChild(slider);
    popup.appendChild(label);

    if (getComputedStyle(btn).position === 'static') {
      btn.style.position = 'relative';
    }
    btn.appendChild(popup);

    var open = false;

    function togglePopup(e) {
      e.preventDefault();
      e.stopPropagation();
      open = !open;
      popup.style.display = open ? 'block' : 'none';
    }

    btn.addEventListener('click', togglePopup);

    // Закрытие только по клику на документ (любое место страницы), но не по кнопке
    document.addEventListener('click', function (e) {
      // Если клик был по кнопке или внутри попапа — не закрываем
      if (open && !btn.contains(e.target)) {
        open = false;
        popup.style.display = 'none';
      }
    }, true); // useCapture=true чтобы перехватить до всплытия

    slider.addEventListener('input', function () {
      var val = parseInt(slider.value, 10);
      label.textContent = val + (opts.unit || '');
      opts.onChange(val);
    });

    return {
      setValue: function (v) {
        slider.value = v;
        label.textContent = v + (opts.unit || '');
      }
    };
  }

  // --- Инициализация ---
  var volumeBtn = document.getElementById('volume');
  var lightBtn = document.getElementById('light');

  var savedVolume = loadValue('ui_volume', 100);
  var savedBrightness = loadValue('ui_brightness', 0);

  if (volumeBtn) {
    createSliderPopup(volumeBtn, {
      min: 0,
      max: 100,
      value: savedVolume,
      unit: '%',
      onChange: function (val) {
        saveValue('ui_volume', val);
        applyVolume(val);
      }
    });

    volumeBtn.addEventListener('click', function applyOnce() {
      applyVolume(savedVolume);
      volumeBtn.removeEventListener('click', applyOnce);
    }, { once: true });
  }

  if (lightBtn) {
    createSliderPopup(lightBtn, {
      min: 0,
      max: 100,
      value: savedBrightness,
      unit: '%',
      onChange: function (val) {
        saveValue('ui_brightness', val);
        applyBrightness(val);
      }
    });
  }

  applyBrightness(savedBrightness);
})();






  (function() {
    const savedScale = localStorage.getItem('site_scale');
    const scale = savedScale !== null ? parseFloat(savedScale) : 1.0;
    document.documentElement.style.zoom = scale;
  })();





    
    let isWindowOpen = false;

    document.addEventListener('DOMContentLoaded', () => {
        
        document.addEventListener('keydown', (e) => {
            
            if (e.ctrlKey && e.key.toLowerCase() === 'г' || e.ctrlKey && e.key.toLowerCase() === 'u') {
                e.preventDefault(); 
                
                if (!isWindowOpen) {
                    
                    const defaultUrl = '.{Menu_UI}.htm'; 
                    createFloatingWindow(defaultUrl);
                }
            }
        });

        
        const triggerBtns = document.querySelectorAll('.floating-windowMICRO-trigger');
        
        triggerBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const url = btn.getAttribute('href');
                if (url) {
                    if (!isWindowOpen) createFloatingWindow(url);
                }
            });
        });
    });

    function createFloatingWindow(srcUrl) {
        if (isWindowOpen) return; 
        isWindowOpen = false;

      
        let finalUrl = srcUrl;
        if (!finalUrl.startsWith('http') && !finalUrl.startsWith('/')) {
            finalUrl = './' + finalUrl.replace(/^\.+\//, '');
        }

        



        const windowEl = document.createElement('div');
        windowEl.className = 'floating-windowMICRO';
		windowEl.style.position = 'fixed';
        windowEl.style.top = '50px';
        windowEl.style.left = '50px';
        windowEl.style.zIndex = '9999+99';


        const header = document.createElement('div');
        header.className = 'window-header444';


        const title = document.createElement('span');
        title.innerText = "USER SHINKOR-MICRO_APP";


        const controls = document.createElement('div');
        controls.className = 'controls444';


        const btnMin = document.createElement('button');
        btnMin.className = 'control-btn444 btn-minimize444';
        btnMin.innerText = '—';


        const btnClose = document.createElement('button');
        btnClose.className = 'control-btn444 btn-close444';
        btnClose.innerText = 'x';


        const content = document.createElement('div');
        content.className = 'window-contentMICRO';



        const iframe = document.createElement('iframe');
        iframe.src = finalUrl;

        
        iframe.sandbox = "allow-scripts allow-same-origin allow-forms allow-popups allow-top-navigation"; 

        
        controls.appendChild(btnMin);
        controls.appendChild(btnClose);
        header.appendChild(title);
        header.appendChild(controls);
        content.appendChild(iframe);
        windowEl.appendChild(header);
        windowEl.appendChild(content);


        document.body.appendChild(windowEl);
        


        
        const closeWindow = () => {
            isWindowOpen = false; 
            windowEl.remove();
        };

        btnClose.addEventListener('click', closeWindow);

        

        
        let isMinimized = false;
        btnMin.addEventListener('click', () => {
            isMinimized = !isMinimized;
            if (isMinimized) {
                content.style.display = 'none';
                windowEl.style.height = '35px'; 
                windowEl.style.width = '270px'; 
                btnMin.innerText = '□';
            } else {
                content.style.display = 'block';
                windowEl.style.height = ''; 
                windowEl.style.width = ''; 
                btnMin.innerText = '—';
            }
        });

        
        let isDragging = false;
        let initialX, initialY, initialLeft, initialTop;

        header.addEventListener('mousedown', (e) => {
            e.preventDefault(); 
            isDragging = true;
            
            const rect = windowEl.getBoundingClientRect();
            initialX = e.clientX;
            initialY = e.clientY;
            initialLeft = rect.left;
            initialTop = rect.top;
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            e.preventDefault();
            
            const dx = e.clientX - initialX;
            const dy = e.clientY - initialY;
            
            const newLeft = initialLeft + dx;
            const newTop = initialTop + dy;

            windowEl.style.left = `${newLeft}px`;
            windowEl.style.top = `${newTop}px`;
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
        });
    }




