
(function() {
    // 1. Создаём оверлей
    const overlay = document.createElement('div');
    overlay.id = 'dark-overlay';
    
    // 2. Вшиваем стили прямо в JS (чтобы не трогать CSS файл)
    overlay.style.cssText = `
        position: fixed;
        top: 0; left: 0; width: 100%; height: 100%;
        background-color: rgba(17, 0, 0, 0);
        pointer-events: none;
        z-index: 99999999999999999999999999999999999;
        transition: background-color 0.3s ease;
    `;

    // Добавляем на страницу
    document.body.appendChild(overlay);

    // Функция установки прозрачности
    function setDarkness(level) {
        const safeLevel = Math.max(0, Math.min(1, level));
        
        if (safeLevel > 0) {
           
            overlay.style.backgroundColor = `rgba(17, 0, 0, ${safeLevel})`;
        } else {
            overlay.style.pointerEvents = 'none'; // Не мешаем кликать по сайту
            overlay.style.backgroundColor = 'rgba(17, 0, 0, 0)';
        }
    }

    // Слушаем нажатие клавиш
    document.addEventListener('keydown', (e) => {
        // Работает только с Ctrl + цифры 1-9
        if (e.ctrlKey && e.key >= '0' && e.key <= '9') {
            const num = parseInt(e.key);
            // Логика: 1 = 10%, 9 = 90%
            setDarkness(num / 10);
        }
    });


})();





(function() {
    // ... (стили и HTML без изменений) ...
    const styleSheet = document.createElement("style");
    styleSheet.innerText = `
        #custom-menu {
            position: absolute;
            display: none;
            width: 240px;
            background: rgba(0,0,0,0.8);
            border: 1px solid rgb(102, 55, 250);
            box-shadow: 0 0 12px rgba(12, 12, 12, 0.5);
            border-radius:4px;
            z-index: 10000;
            padding: 0px 0;
            margin: 0;
            list-style: none;
            font-family: monospace;
        }
        #custom-menu li {
            padding: 8px 15px;
            cursor: pointer;
            border-bottom: 1px solid rgba(122, 75, 255, 0.7);
            font-size: 12px;
            color: white;
            white-space: nowrap;
        }
        #custom-menu li:hover {
            background: rgba(102, 55, 255, 0.4);
            color: white;
        }
        #custom-menu li:active {
            background: rgba(102, 55, 255, 0.4);
            color: white;
        }
    `;
    document.head.appendChild(styleSheet);

    const menuHtml = `
        <ul id="custom-menu">
            <li id="menu-reload">Перезагрузить</li>
            <li id="menu-fullscreen">Развернуть на весь экран</li>
            <li id="menu-copy-link">Копировать ссылку на окно          ></li>
            <li style="border-bottom: rgba(0,0,0,0.0)"  id="menu-save-images">Сохранить картинки ></li>
        </ul>
    `;
    
    const divContainer = document.createElement('div');
    divContainer.innerHTML = menuHtml;
    document.body.appendChild(divContainer);
    
    const menu = document.getElementById('custom-menu');

    // --- ИСПРАВЛЕННАЯ МЕХАНИКА (С УЧЁТОМ СКРОЛЛА) ---

    document.addEventListener('contextmenu', function(event) {
        event.preventDefault();
        menu.style.display = 'block';

        // ВАЖНО: Используем pageX и pageY вместо clientX/Y
        // Они учитывают прокрутку страницы (scroll)
        const x = event.pageX;
        const y = event.pageY;

        const menuWidth = menu.offsetWidth;
        const menuHeight = menu.offsetHeight;

        let leftPos = x;
        let topPos = y;

        // Корректировка, если меню вылезает за правый край
        if (x + menuWidth > document.documentElement.scrollWidth) {
            leftPos = x - menuWidth;
        }

        // Корректировка, если меню вылезает за нижний край
        if (y + menuHeight > document.documentElement.scrollHeight) {
            topPos = y - menuHeight;
        }

        // Финальная защита от отрицательных значений
        if (leftPos < 0) leftPos = 0;
        if (topPos < 0) topPos = 0;

        menu.style.left = leftPos + 'px';
        menu.style.top = topPos + 'px';
    });

    document.addEventListener('click', function() {
        menu.style.display = 'none';
    });

    // Обработчики кнопок (без изменений)
    document.getElementById('menu-reload').addEventListener('click', () => location.reload());

    document.getElementById('menu-copy-link').addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(window.location.href);
            alert('Ссылка скопирована в буфер обмена!');
        } catch (err) {
            console.error('Не удалось скопировать: ', err);
            alert('Ошибка копирования');
        }
    });

    document.getElementById('menu-fullscreen').addEventListener('click', () => {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => alert(`Ошибка: ${err.message}`));
        } else {
            if (document.exitFullscreen) document.exitFullscreen();
        }
    });

    document.getElementById('menu-save-images').addEventListener('click', () => {
        const images = document.querySelectorAll('img');
        let html = '<h3>Список картинок на странице:</h3><ul>';
        images.forEach(img => {
            const src = img.src;
            const fileName = src.substring(src.lastIndexOf('/') + 1);
            html += `<li><a href="${src}" target="_blank">${fileName}</a></li>`;
        });
        html += '</ul>';
        console.log(html); 
        alert(`Найдено картинок: ${images.length}. Проверьте консоль (F12).`);
    });
})();
