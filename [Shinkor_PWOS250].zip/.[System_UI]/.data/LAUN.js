
(function() {
    // 1. Создаём оверлей
    const overlay = document.createElement('div');
    overlay.id = 'dark-overlay';
    
    // 2. Вшиваем стили прямо в JS (чтобы не трогать CSS файл)
    overlay.style.cssText = `
        position: fixed;
        top: 0; left: 0; width: 100%; height: 100%;
        background-color: rgba(50, 0, 0, 0);
        pointer-events: none;
        z-index: 99999999999999999999999999999999999;
        transition: background-color 0.3s ease;
    `;

    // Добавляем на страницу
    document.body.appendChild(overlay);

    // Функция установки прозрачности
    function setDarkness(level) {
        const safeLevel = Math.max(0, Math.min(1, level));
        
        if (safeLevel > 0) {
           
            overlay.style.backgroundColor = `rgba(17, 0, 0, ${safeLevel})`;
        } else {
            overlay.style.pointerEvents = 'none'; // Не мешаем кликать по сайту
            overlay.style.backgroundColor = 'rgba(17, 0, 0, 0)';
        }
    }

    // Слушаем нажатие клавиш
    document.addEventListener('keydown', (e) => {
        // Работает только с Ctrl + цифры 1-9
        if (e.ctrlKey && e.key >= '0' && e.key <= '9') {
            const num = parseInt(e.key);
            // Логика: 1 = 10%, 9 = 90%
            setDarkness(num / 10);
        }
    });


})();




(function() {
    // --- СТИЛИ (Без изменений, как в твоем коде) ---
    const styleSheet = document.createElement("style");
    styleSheet.innerText = `
        #custom-menu {
            position: absolute;
            display: none;
            width: 240px;
            background: rgba(0,0,0,0.8);
            border: 1px solid rgb(102, 55, 250);
            box-shadow: 0 0 12px rgba(12, 12, 12, 0.5);
            border-radius:4px;
            z-index: 10000;
            padding: 0px 0;
            margin: 0;
            list-style: none;
            font-family: monospace;
        }
        #custom-menu li {
            padding: 8px 15px;
            cursor: pointer;
            border-left: 14px solid rgba(0,0,0,0.0);
            border-right: 14px solid rgba(0,0,0,0.0);
            border-bottom: 1px solid rgba(122, 75, 255, 0.7);
            font-size: 12px;
            color: white;
            white-space: nowrap;
        }
		    
#custom-menu .iopop {
  display: block;
  padding: 8px 15px;
  color: #ddddff;
  text-decoration: none;
  cursor: pointer;
  white-space: nowrap;
  border-left: 14px solid rgba(0,0,0,0.0);
  border-right: 14px solid rgba(0,0,0,0.0);
  border-bottom: 1px solid rgba(122, 75, 255, 0.7);
  font-size: 12px;
}
#custom-menu .iopop:hover {
  background: rgba(102, 55, 255, 0.4);

}
#custom-menu .iopop:active {
  background: rgba(102, 55, 255, 0.6);

}
        #custom-menu li:hover {
            background: rgba(102, 55, 255, 0.4);
            color: white;
        }
        #custom-menu li:active {
            background: rgba(102, 55, 255, 0.6);
            color: white;
        }
    `;
    document.head.appendChild(styleSheet);

    // --- HTML (Без изменений) ---
    const menuHtml = `
        <ul id="custom-menu">
            <li id="menu-open">Открыть</li> 
            <li style="border-bottom: rgba(0,0,0,0.0)" id="menu-reload">Перезагрузить (F5)</li>
            <li id="menu-fullscreen">Развернуть на весь экран (F11)</li>
            <li style="border-bottom: rgba(0,0,0,0.0)">Вставить (Ctrl+V)</li>
            <li style="border-bottom: rgba(0,0,0,0.0)">Копировать (Ctrl+C)</li>
            <li>Вырезать (Ctrl+X)</li>
			<a style="border-bottom: 1px solid rgba(0,0,0,0.0)" class="iopop" href="{Desktop_UI}.htm">Вернутся на рабочий стол ›</a>
			<a class="iopop" href=".[pUSER;DEVELOPlist].htm">Для разработчиков ›</a>
            <li style="border-bottom: rgba(0,0,0,0.0)" id="menu-copy-link">Копировать ссылку на окно ┐</li>
            <li style="border-bottom: rgba(0,0,0,0.0)" id="menu-save-images">Сохранить все картинки ┐</li>
        </ul>
    `;
    
    const divContainer = document.createElement('div');
    divContainer.innerHTML = menuHtml;
    document.body.appendChild(divContainer);
    
    const menu = document.getElementById('custom-menu');
    let lastContextTarget = null; // Элемент, на котором был клик правой кнопкой

    // --- МЕХАНИКА МЕНЮ (С УЧЕТОМ СКРОЛЛА) ---
    document.addEventListener('contextmenu', function(event) {
        event.preventDefault();
        menu.style.display = 'block';
        
        // Запоминаем элемент, на который кликнули
        lastContextTarget = event.target;

        const x = event.pageX;
        const y = event.pageY;

        const menuWidth = menu.offsetWidth;
        const menuHeight = menu.offsetHeight;

        let leftPos = x;
        let topPos = y;

        if (x + menuWidth > document.documentElement.scrollWidth) {
            leftPos = x - menuWidth;
        }
        if (y + menuHeight > document.documentElement.scrollHeight) {
            topPos = y - menuHeight;
        }

        if (leftPos < 0) leftPos = 0;
        if (topPos < 0) topPos = 0;

        menu.style.left = leftPos + 'px';
        menu.style.top = topPos + 'px';
    });

    document.addEventListener('click', function() {
        menu.style.display = 'none';
    });

    // --- ОБРАБОТЧИКИ КНОПОК ---

    // 1. ПЕРЕЗАГРУЗКА
    document.getElementById('menu-reload').addEventListener('click', () => location.reload());

    // 2. ПОЛНЫЙ ЭКРАН
    document.getElementById('menu-fullscreen').addEventListener('click', () => {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => alert(`Ошибка: ${err.message}`));
        } else {
            if (document.exitFullscreen) document.exitFullscreen();
        }
    });

    // 3. КОПИРОВАТЬ ССЫЛКУ НА ОКНО
    document.getElementById('menu-copy-link').addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(window.location.href);
            alert('Ссылка скопирована в буфер обмена!');
        } catch (err) {
            console.error('Не удалось скопировать: ', err);
            alert('Ошибка копирования');
        }
    });

    // 4. СОХРАНИТЬ ВСЕ КАРТИНКИ
    document.getElementById('menu-save-images').addEventListener('click', () => {
        const images = document.querySelectorAll('img');
        let html = '<h3>Список картинок на странице:</h3><ul>';
        images.forEach(img => {
            const src = img.src;
            const fileName = src.substring(src.lastIndexOf('/') + 1);
            html += `<li><a href="${src}" target="_blank">${fileName}</a></li>`;
        });
        html += '</ul>';
        console.log(html); 
        alert(`Найдено картинок: ${images.length}. Проверьте консоль (F12).`);
    });

    // ==========================================
    // НОВАЯ ЛОГИКА: ОТКРЫТЬ, КОПИРОВАТЬ, ВЫРЕЗАТЬ, ВСТАВИТЬ
    // ==========================================

    // Вспомогательная функция: получить URL из элемента
    function getUrlFromElement(el) {
        if (el.tagName === 'A') return el.href;
        if (el.tagName === 'IMG' || el.tagName === 'VIDEO' || el.tagName === 'SOURCE') return el.src;
        
        // Если кликнули на текст внутри ссылки
        const parentLink = el.closest('a');
        if (parentLink) return parentLink.href;

        return null;
    }

    // Вспомогательная функция: получить текст из элемента
    function getTextFromElement(el) {
        // Если есть выделение на странице - берем его
        const selection = window.getSelection();
        if (selection.toString().trim()) return selection.toString();

        // Иначе берем текст из элемента или его родителя
        if (el.innerText) return el.innerText;
        const parent = el.closest('[contenteditable="true"], textarea, input');
        if (parent) return parent.value || parent.innerText;
        
        return el.textContent || '';
    }

    // 5. ОТКРЫТЬ
    document.getElementById('menu-open').addEventListener('click', () => {
        if (!lastContextTarget) return;
        
        const url = getUrlFromElement(lastContextTarget);
        
        if (url) {
            window.open(url, '_blank');
        } else {
            // Если это просто текст или блок - открываем текущую страницу в новой вкладке
            window.open(window.location.href, '_blank');
            console.log('Элемент не имеет URL, открыта текущая страница.');
        }
    });

    // 6. КОПИРОВАТЬ
    document.querySelectorAll('#custom-menu li').forEach(li => {
        if(li.innerText === 'Копировать (Ctrl+C)') {
            li.addEventListener('click', async () => {
                if (!lastContextTarget) return;
                
                const url = getUrlFromElement(lastContextTarget);
                const text = getTextFromElement(lastContextTarget);

                let contentToCopy = '';

                // Приоритет: если есть картинка/ссылка - копируем ссылку
                if (url) {
                    contentToCopy = url;
                } else if (text) {
                    // Иначе копируем текст
                    contentToCopy = text;
                }

                if (contentToCopy) {
                    try {
                        await navigator.clipboard.writeText(contentToCopy);
                        alert(`Скопировано:\n${contentToCopy}`);
                    } catch (err) {
                        alert('Не удалось скопировать в буфер (требуется HTTPS или действие пользователя).');
                        console.error(err);
                    }
                } else {
                    alert('Нет данных для копирования');
                }
            });
        }
    });

    // 7. ВЫРЕЗАТЬ (Работает как Копировать, но визуально удаляет элемент)
    document.querySelectorAll('#custom-menu li').forEach(li => {
        if(li.innerText === 'Вырезать (Ctrl+X)') {
            li.addEventListener('click', async () => {
                if (!lastContextTarget) return;

                const url = getUrlFromElement(lastContextTarget);
                const text = getTextFromElement(lastContextTarget);
                let contentToCut = '';

                if (url) contentToCut = url;
                else if (text) contentToCut = text;

                if (contentToCut) {
                    try {
                        await navigator.clipboard.writeText(contentToCut);
                        // Удаляем элемент со страницы (эффект "Вырезания")
                        lastContextTarget.remove(); 
                        alert(`Вырезано и скопировано:\n${contentToCut}`);
                    } catch (err) {
                        alert('Скопировано, но не удалось удалить элемент.');
                        console.error(err);
                    }
                }
            });
        }
    });

    // 8. ВСТАВИТЬ (Самое сложное: читает буфер и вставляет на страницу)
    document.querySelectorAll('#custom-menu li').forEach(li => {
        if(li.innerText === 'Вставить (Ctrl+V)') {
            li.addEventListener('click', async () => {
                try {
                    const clipboardContent = await navigator.clipboard.read();
                    
                    for (const item of clipboardContent) {
                        if (item.types.includes('text/plain')) {
                            const text = await item.getType('text/plain').then(blob => blob.text());
                            // Вставляем текст как новый div рядом с курсором (или в body, если нет target)
                            const insertPoint = lastContextTarget || document.body;
                            const newTextEl = document.createElement('div');
                            newTextEl.style.cssText = "position:absolute; background:white; color:black; padding:10px; border:1px solid #ccc; z-index:9999;";
                            newTextEl.innerText = text;
                            
                            // Позиционируем примерно там, где было меню (упрощенно)
                            if(menu.offsetLeft && menu.offsetTop) {
                                newTextEl.style.left = menu.offsetLeft + 'px';
                                newTextEl.style.top = menu.offsetTop + 'px';
                            } else {
                                newTextEl.style.top = "100px";
                                newTextEl.style.left = "100px";
                            }
                            document.body.appendChild(newTextEl);
                            alert('Текст вставлен на страницу (появился как плавающий блок).');
                            return; // Вставили текст, дальше не идем
                        }

                        if (item.types.includes('image/png') || item.types.includes('image/jpeg')) {
                            const blob = await item.getType(item.types.find(t => t.startsWith('image/')));
                            const imageUrl = URL.createObjectURL(blob);
                            
                            const imgEl = document.createElement('img');
                            imgEl.src = imageUrl;
                            imgEl.style.cssText = "position:absolute; max-width:300px; z-index:9999; border:2px solid purple;";
                            
                            if(menu.offsetLeft && menu.offsetTop) {
                                imgEl.style.left = menu.offsetLeft + 'px';
                                imgEl.style.top = menu.offsetTop + 'px';
                            }
                            
                            document.body.appendChild(imgEl);
                            alert('Картинка вставлена на страницу!');
                            return;
                        }
                    }
                    alert('В буфере обмена нет поддерживаемого контента (текст/картинка).');
                } catch (err) {
                    alert('Не удалось прочитать буфер обмена. Браузер требует HTTPS или явного разрешения.');
                    console.error(err);
                }
            });
        }
    });
})();
