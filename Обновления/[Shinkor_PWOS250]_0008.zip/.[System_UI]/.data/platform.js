﻿(function() {
    // Создаём элемент для отображения названия платформы
    const platformInfo = document.createElement('div');

    // Задаём стили для элемента
    Object.assign(platformInfo.style, {
        position: 'fixed',
        bottom: '6px',           // отступ от нижнего края экрана
        right: '14%',           // расположение в 12 % от правого края
        background:' rgba(0, 0, 0, 0.3)', // полупрозрачный чёрный фон
		border:' 1px solid rgba(138,43,182, 0.6)',
        color: '#c9c9c9',           // белый цвет текста
        padding: '6px 12px',     // внутренние отступы
        borderRadius: '4px',      // скругление углов
        fontSize: '11px',       // размер шрифта
        fontFamily: 'monospace', // шрифт
        boxShadow: '0 3px 2px rgba(122, 55, 122, 0.6)', // тень
        whiteSpace: 'nowrap',      // текст в одну строку
	

    });

    // Получаем информацию о платформе
    const userAgent = navigator.userAgent;
    let platformName = 'OS';

    if (/Windows/i.test(userAgent)) {
        platformName = 'WIN-32';
    } else if (/Mac/i.test(userAgent)) {
        platformName = 'MAC';
    } else if (/Linux/i.test(userAgent)) {
        platformName = 'LINUX';
    } else if (/Android/i.test(userAgent)) {
        platformName = 'ANDROID';
    } else if (/iPad/i.test(userAgent)) {
        platformName = 'IPAD';
	} else if (/iOS/i.test(userAgent)) {
        platformName = 'IOS';
    } else if (/iPhone/i.test(userAgent)) {
        platformName = 'IPHONE';
    }

    // Устанавливаем текст элемента
    platformInfo.textContent = `${platformName}`;

    // Добавляем элемент в тело документа
    document.body.appendChild(platformInfo);

    // Опционально: добавляем обработчик для обновления при изменении размера окна
    window.addEventListener('resize', function() {
        platformInfo.style.right = '11%';
    });
})();



(function() {
 
  const layoutElement = document.createElement('div');
  layoutElement.id = 'keyboard-layout';
  layoutElement.dataset.lang = 'Unknown';
  layoutElement.textContent = 'EN';
  document.body.appendChild(layoutElement);

  const style = document.createElement('style');
  style.textContent = `
    #keyboard-layout {
      position: fixed;
      bottom: 7px;
      right: 24%;
      background: rgba(0, 0, 0, 0.3);
      color: #c9c9c9;
      box-Shadow: 0 3px 2px rgba(122, 55, 122, 0.6);
      padding: 6px 4px;
      border-radius: 4px;
      font-family: monospace;

      font-size: 10px;
      // pointer-events: none; /* Чтобы плашка не мешала кликать мышкой */
      
      min-width: 25px;
      text-align: center;
      border: 1px solid rgba(138,43,182, 0.6);
      transition: color 0.2s, border-color 0.2s;
    }
    
    // #keyboard-layout[data-lang="EN"] { color: #4ade80; border-color: #4ade80; text-shadow: 0 0 4px rgba(74, 222, 128, 0.6); }
    // #keyboard-layout[data-lang="RU"] { color: #fbbf24; border-color: #fbbf24; text-shadow: 0 0 4px rgba(251, 191, 36, 0.6); }
    // #keyboard-layout[data-lang="CN"] { color: #ef4444; border-color: #ef4444; text-shadow: 0 0 4px rgba(239, 68, 68, 0.6); }
    // #keyboard-layout[data-lang="AR"] { color: #6369d1; border-color: #6369d1; text-shadow: 0 0 4px rgba(99, 105, 209, 0.6); }
    // #keyboard-layout[data-lang="JA"] { color: #8b5cf6; border-color: #8b5cf6; text-shadow: 0 0 4px rgba(139, 92, 246, 0.6); }
    // #keyboard-layout[data-lang="KO"] { color: #10b981; border-color: #10b981; text-shadow: 0 0 4px rgba(16, 185, 129, 0.6); }
    // #keyboard-layout[data-lang="Unknown"] { color: #9ca3af; border-color: #9ca3af; }
  `;
  document.head.appendChild(style);

  

  function getLayoutByChar(char) {
    if (!char || char.length !== 1) return 'Unknown';

    const code = char.charCodeAt(0);

  
    if ((code >= 65 && code <= 90) || (code >= 97 && code <= 122)) return 'EN';
    
  
    if ((code >= 1040 && code <= 1103) || code === 1025 || code === 1105) return 'RU';
    
  
    if (code >= 1536 && code <= 1791) return 'AR';
    
  
    if ((code >= 12352 && code <= 12447) || (code >= 12448 && code <= 12543)) return 'JA';
    
   
    if (code >= 44032 && code <= 55203) return 'KO';
    
    if (code >= 19968 && code <= 40959) return 'CN';

    return 'Unknown';
  }

  let lastLayout = 'Unknown';

  function updateDisplay(layout) {
    if (layout === lastLayout) return;
    
    lastLayout = layout;
    layoutElement.textContent = layout === 'Unknown' ? 'EN' : layout;
    layoutElement.dataset.lang = layout;
  }

 
  document.addEventListener('input', (event) => {
    const target = event.target;
    
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
      const value = target.value;
      if (value && value.length > 0) {
     
        const lastChar = value.slice(-1);
        const layout = getLayoutByChar(lastChar);
        updateDisplay(layout);
      }
    }
  }, true);

  document.addEventListener('keydown', (event) => {
    let layout = 'Unknown';
    let key = event.key;

    
    if (key.startsWith('Key') && key.length > 3) {
      key = key.substring(3).toLowerCase();
      if (key.length === 1) {
        layout = getLayoutByChar(key);
      }
    } 
  
    else if (key.length === 1 && !key.startsWith('Control') && !key.startsWith('Alt')) {
      layout = getLayoutByChar(key);
    }

    if (layout !== 'Unknown') {
      updateDisplay(layout);
    }
  });

  updateDisplay('Unknown');

})();

