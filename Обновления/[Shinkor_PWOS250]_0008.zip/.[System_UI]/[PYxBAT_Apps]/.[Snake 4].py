import tkinter as tk
from tkinter import colorchooser
import random
import json
import os
import sys

try:
    from PIL import Image, ImageTk, ImageColor
except ImportError:
    print("                           S.P.G.")
    print("+-----------------------------------------------------------+")
    print("|На этом устройстве отсутствуют нужные элементы.")
    print("|Я сейчас их установлю, иначе игра не заработает....")
    print("+-----------------------------------------------------------+")
    try:
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "Pillow"])
        from PIL import Image, ImageTk, ImageColor
        print("Я всё скачал, теперь запускаю игру!!!")
    except:
        print("Чёт не вышло установить нужные файлы, так что сегодня не поиграеш. -_[0_0]_-")
        Image = ImageTk = ImageColor = None


IMAGES_FOLDER = "snake_images"

def create_images_folder():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), IMAGES_FOLDER)
    if not os.path.exists(path):
        try:
            os.makedirs(os.path.join(path, "enemies"), exist_ok=True)
            os.makedirs(os.path.join(path, "snake"), exist_ok=True)
            os.makedirs(os.path.join(path, "food"), exist_ok=True)
            os.makedirs(os.path.join(path, "background"), exist_ok=True)
            os.makedirs(os.path.join(path, "rocks"), exist_ok=True)
            print(f"Папка с изображениями создана: {path}")
        except OSError as e:
            print(f"Не удалось создать папку: {e}")

create_images_folder()

class SnakeGame:
    def __init__(self, root, speed, enemy_speed, food_speed, food_count, grass_colors, enemy_count, rock_count, snake_color, hard_mode=False):
        self.root = root
        self.root.title("S.P.G.")
        self.screen_width = root.winfo_screenwidth()
        self.screen_height = root.winfo_screenheight()
        self.canvas = tk.Canvas(root, width=self.screen_width, height=self.screen_height, bg="dark green")
        self.canvas.pack()

        self.snake_image = self.enemy_image = self.rock_image = None
        self.grass_colors = grass_colors
        self.grass_texture = self.create_grass_texture(self.screen_width, self.screen_height)
        self.food_image = None  # Удалили загрузку food_image здесь
        if Image and ImageTk:
            try:
                image_path = lambda sub, name: os.path.join(IMAGES_FOLDER, sub, name + ".png")
                load_image = lambda path: ImageTk.PhotoImage(Image.open(path))
                self.snake_image = load_image(image_path("snake", "snake"))
                self.enemy_image = load_image(image_path("enemies", "enemy"))
                self.rock_image = load_image(image_path("rocks", "rock"))
                # Load apple image
                try:
                    self.food_image = load_image(image_path("food", "apple"))
                except FileNotFoundError:
                    print("Файл apple.png не найден, еда будет отображаться как прямоугольник.")

            except FileNotFoundError as e:
                print(f"Файл не найден: {e}")
            except Exception as e:
                print(f"Ошибка загрузки изображения: {e}")

        self.snake = [(100, 100), (90, 100), (80, 100)]
        self.food = [self.create_food() for _ in range(food_count)]
        self.enemies = [self.create_enemy() for _ in range(enemy_count if not hard_mode else int(enemy_count * 1.3))]
        self.rocks = self.create_rocks(rock_count) # Передаем rock_count в create_rocks()
        self.direction = "Right"
        self.score = 0
        self.speed = speed
        self.enemy_speed = enemy_speed
        self.food_speed = food_speed
        self.food_count = food_count
        self.enemy_count = enemy_count
        self.rock_count = rock_count
        self.game_over_flag = False
        self.hard_mode = hard_mode
        self.lives = 3
        self.deaths = 0
        self.snake_color = snake_color
        self.root.bind("<KeyPress>", self.change_direction)
        # Привязка клавиш WASD
        self.root.bind("w", lambda event: self.change_direction_wasd("Up"))
        self.root.bind("a", lambda event: self.change_direction_wasd("Left"))
        self.root.bind("s", lambda event: self.change_direction_wasd("Down"))
        self.root.bind("d", lambda event: self.change_direction_wasd("Right"))
        # Привязка клавиши Q для смерти
        self.root.bind("q", self.kill_snake)
        self.update()

    def create_grass_texture(self, width, height):
        tile_size = 5  # Размер одного "пикселя" травы
        img = Image.new("RGB", (width, height))
        pixels = img.load()
        for i in range(0, width, tile_size):
            for j in range(0, height, tile_size):
                color = tuple(self.grass_colors[random.randint(0, len(self.grass_colors)-1)])

                # Заполняем квадрат tile_size x tile_size этим цветом
                for x in range(i, min(i + tile_size, width)):
                    for y in range(j, min(j + tile_size, height)):
                        pixels[x, y] = color
        return ImageTk.PhotoImage(img)

    def update_grass_colors(self, new_colors):
        self.grass_colors = new_colors
        self.grass_texture = self.create_grass_texture(self.screen_width, self.screen_height)

    def create_food(self):
        return (random.randint(0, (self.screen_width // 10) - 1) * 10,
                random.randint(0, (self.screen_height // 10) - 1) * 10)

    def create_enemy(self):
        return (random.randint(0, (self.screen_width // 10) - 1) * 10,
                random.randint(0, (self.screen_height // 10) - 1) * 10)

    def create_rocks(self, count=5):
        return [(random.randint(0, (self.screen_width // 10) - 1) * 10,
                 random.randint(0, (self.screen_height // 10) - 1) * 10) for _ in range(count)]

    def change_direction(self, event):
        key = event.keysym
        dirs = {"Up": "Down", "Down": "Up", "Left": "Right", "Right": "Left"}
        if key in dirs and self.direction != dirs[key]:
            self.direction = key

    def change_direction_wasd(self, direction):
        dirs = {"Up": "Down", "Down": "Up", "Left": "Right", "Right": "Left"}
        if direction in dirs and self.direction != dirs[direction]:
            self.direction = direction

    def kill_snake(self, event):
        """Убивает змейку при нажатии на клавишу 'q'."""
        self.deaths += 1
        self.handle_death()

    def update(self):
        if not self.game_over_flag:
            self.move_snake()
            self.move_enemies()
            self.check_collision()
            self.check_food()
            self.check_rock_collision()

            self.canvas.delete("all")
            self.draw_background()
            self.draw_snake()
            self.draw_food()
            self.draw_enemies()
            self.draw_rocks()
            self.draw_score()
            self.draw_lives()

            self.root.after(self.speed, self.update)
        else:
            self.show_restart_menu()

    def move_snake(self):
        x, y = self.snake[0]
        dx, dy = {"Up": (0, -10), "Down": (0, 10), "Left": (-10, 0), "Right": (10, 0)}[self.direction]
        new_head = ((x + dx) % self.screen_width, (y + dy) % self.screen_height)
        self.snake = [new_head] + self.snake[:-1]

    def move_enemies(self):
        for i, (x, y) in enumerate(self.enemies):
            direction = random.choice(["Up", "Down", "Left", "Right"])
            dx, dy = {"Up": (0, -10), "Down": (0, 10), "Left": (-10, 0), "Right": (10, 0)}[direction]
            self.enemies[i] = ((x + dx) % self.screen_width, (y + dy) % self.screen_height)

    def check_collision(self):
        x, y = self.snake[0]
        if any((x, y) == seg for seg in self.snake[1:]) or any((x, y) == enemy for enemy in self.enemies):
            self.deaths += 1
            self.handle_death()

    def handle_death(self):
        self.lives -= 1
        if self.lives <= 0:
            self.game_over_flag = True
        else:
            self.snake = [(100, 100), (90, 100), (80, 100)]
            self.root.after(1000, self.reset_after_death)

    def reset_after_death(self):
        self.direction = "Right"
        self.enemies = [self.create_enemy() for _ in range(self.enemy_count if not self.hard_mode else int(self.enemy_count * 1.3))]
        if not self.game_over_flag:
            self.update()

    def check_food(self):
        x, y = self.snake[0]
        for i, (fx, fy) in enumerate(self.food):
            if (x, y) == (fx, fy):
                self.snake.append(self.snake[-1])
                self.food[i] = self.create_food()
                self.score += 1
                self.update_speed()

    def check_rock_collision(self):
        x, y = self.snake[0]
        if any((x, y) == rock for rock in self.rocks):
            self.deaths += 1
            self.handle_death()

    def draw_background(self):
        if self.grass_texture:
            self.canvas.create_image(0, 0, anchor=tk.NW, image=self.grass_texture)
        else:
            self.canvas.create_rectangle(0, 0, self.screen_width, self.screen_height, fill="dark green")

    def draw_snake(self):
        img = self.snake_image
        for x, y in self.snake:
            self.canvas.create_image(x, y, anchor=tk.NW, image=img) if img else self.canvas.create_rectangle(x, y, x + 10, y + 10, fill=self.snake_color)

    def draw_food(self):
        if self.food_image:
            for x, y in self.food:
                self.canvas.create_image(x, y, anchor=tk.NW, image=self.food_image)
        else:
            for x, y in self.food:
                self.canvas.create_rectangle(x, y, x + 10, y + 10, fill="red")

    def draw_enemies(self):
        img = self.enemy_image
        for x, y in self.enemies:
            self.canvas.create_image(x, y, anchor=tk.NW, image=img) if img else self.canvas.create_rectangle(x, y, x + 10, y + 10, fill="blue")

    def draw_rocks(self):
        img = self.rock_image
        for x, y in self.rocks:
            self.canvas.create_image(x, y, anchor=tk.NW, image=img) if img else self.canvas.create_rectangle(x, y, x + 10, y + 10, fill="gray")

    def draw_score(self):
        self.canvas.create_text(30, 10, text=f"Score: {self.score}", fill="white", font=("monospace", 12))

    def draw_lives(self):
        self.canvas.create_text(30, 30, text=f"Lives: {self.lives}", fill="white", font=("monospace", 12))

    def update_speed(self):
        self.speed = max(50, self.speed - 10) if self.score % 5 == 0 else self.speed

    def show_restart_menu(self):
        self.canvas.delete("all")
        center_x, center_y = self.screen_width // 2, self.screen_height // 2
        self.canvas.create_text(center_x, center_y - 50, text="Game Over", fill="white", font=("monospace", 20))
        self.canvas.create_text(center_x, center_y, text="Играем еще раз?", fill="white", font=("monospace", 14))

        yes_x1, yes_y1 = center_x - 50, center_y + 50
        yes_x2, yes_y2 = center_x + 50, center_y + 80
        no_x1, no_y1 = center_x - 50, center_y + 100
        no_x2, no_y2 = center_x + 50, center_y + 130

        self.canvas.create_rectangle(yes_x1, yes_y1, yes_x2, yes_y2, fill="green")
        self.canvas.create_text(center_x, center_y + 65, text="Да", fill="white", font=("monospace", 14))
        self.canvas.create_rectangle(no_x1, no_y1, no_x2, no_y2, fill="red")
        self.canvas.create_text(center_x, center_y + 115, text="Нет", fill="white", font=("monospace", 14))

        self.canvas.bind("<Button-1>", self.handle_restart_click)

    def handle_restart_click(self, event):
        x, y = event.x, event.y
        center_x, center_y = self.screen_width // 2, self.screen_height // 2
        if center_x - 50 <= x <= center_x + 50:
            if center_y + 50 <= y <= center_y + 80:
                self.restart_game()
            elif center_y + 100 <= y <= center_y + 130:
                self.root.destroy()

    def restart_game(self):
        self.save_score()
        self.root.destroy()
        root = tk.Tk()
        self.set_fullscreen(root)
        menu = GameMenu(root)
        root.mainloop()

    def save_score(self):
        try:
            with open("records.json", "r") as f:
                records = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            records = {"max_score": 0}

        if self.score > records["max_score"]:
            records["max_score"] = self.score
            try:
                with open("records.json", "w") as f:
                    json.dump(records, f)
            except OSError as e:
                print(f"Ошибка записи рекорда: {e}")

    def set_fullscreen(self, root):
        root.state('zoomed') if sys.platform == "win32" else root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")

class GameMenu:
    def __init__(self, root):
        self.root = root
        self.root.title("S.P.G.")
        self.set_fullscreen()

        self.default_grass_colors = [[100, 150, 50], [80, 130, 40], [120, 170, 60]] # Значения по умолчанию
        self.default_snake_color = "green"

        self.label = tk.Label(root, text="-________________-{Меню}-________________-", font=("monospace", 12))
        self.label.pack(pady=20)

        self.start_button = tk.Button(root, text="-{_Продолжить_}-", command=self.start_game)
        self.start_button.pack(pady=10)

        self.hard_button = tk.Button(root, text="-{_Начать_игру_}-", command=self.start_hard_game)
        self.hard_button.pack(pady=10)

        self.records_button = tk.Button(root, text="-{_Рекорды_}-", command=self.show_records)
        self.records_button.pack(pady=10)

        self.settings_button = tk.Button(root, text="-{_Настройки_}-", command=self.show_settings)
        self.settings_button.pack(pady=10)

        self.load_settings()
    
    def set_fullscreen(self):
        if sys.platform == "win32":
            self.root.state('zoomed')  # Полноэкранный режим на Windows
        else:
            # Для других систем (Linux, MacOS) пытаемся получить размер экрана
            width = self.root.winfo_screenwidth()
            height = self.root.winfo_screenheight()
            self.root.geometry("%dx%d" % (width, height))

    def load_settings(self):
        try:
            with open("settings.json", "r") as f:
                settings = json.load(f)
                self.speed = settings.get("speed", 127)
                self.enemy_speed = settings.get("enemy_speed", 127)
                self.food_speed = settings.get("food_speed", 198)
                self.food_count = settings.get("food_count", 8)
                self.grass_colors = settings.get("grass_colors", self.default_grass_colors)
                self.snake_color = settings.get("snake_color", self.default_snake_color)
                # Загружаем количество врагов и камней. Если их нет, используем значения по умолчанию
                self.enemy_count = settings.get("enemy_count", 12)
                self.rock_count = settings.get("rock_count", 15)

        except (FileNotFoundError, json.JSONDecodeError):
            self.speed = self.enemy_speed = self.food_speed = 100
            self.food_count = 1
            self.grass_colors = self.default_grass_colors  # При отсутствии файла или ошибки json - значения по умолчанию
            self.snake_color = self.default_snake_color
            self.enemy_count = 3
            self.rock_count = 5

    def start_game(self):
        self.start_new_game(hard_mode=False)

    def start_hard_game(self):
        self.start_new_game(hard_mode=True)
    
    def start_new_game(self, hard_mode=False):
        self.root.destroy()
        game_root = tk.Tk()
        self.set_fullscreen_root(game_root)
        game = SnakeGame(game_root, self.speed, self.enemy_speed, self.food_speed, self.food_count, self.grass_colors, self.enemy_count, self.rock_count, self.snake_color, hard_mode)
        game_root.mainloop()

    def show_records(self):
        self.show_new_window(RecordsMenu)

    def show_settings(self):
        self.show_new_window(SettingsMenu, self)

    def show_new_window(self, cls, *args):
        self.root.destroy()
        new_root = tk.Tk()
        self.set_fullscreen_root(new_root)
        cls(new_root, *args)
        new_root.mainloop()

    def set_fullscreen_root(self, root):
        root.state('zoomed') if sys.platform == "win32" else root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")


class RecordsMenu:
    def __init__(self, root):
        self.root = root
        self.root.title("-________________-{Рекорды}-________________-")
        self.set_fullscreen()

        self.label = tk.Label(root, text="-____{RESULT:}____-", font=("monospace", 12))
        self.label.pack(pady=20)

        self.max_score = self.load_max_score()
        self.label_max_score = tk.Label(root, text="____-Максимальный рекорд: {}".format(self.max_score), font=("monospace", 10))
        self.label_max_score.pack(pady=10)

        self.food_count = self.load_food_count()
        self.label_food_count = tk.Label(root, text="____-Количество яблок: {}".format(self.food_count), font=("monospace", 10))
        self.label_food_count.pack(pady=10)

        self.back_button = tk.Button(root, text="_-{Вернуться в меню}-_", command=self.back_to_menu)
        self.back_button.pack(pady=10)

    def set_fullscreen(self):
        if sys.platform == "win32":
            self.root.state('zoomed')  # Полноэкранный режим на Windows
        else:
            # Для других систем (Linux, MacOS) пытаемся получить размер экрана
            width = self.root.winfo_screenwidth()
            height = self.root.winfo_screenheight()
            self.root.geometry("%dx%d" % (width, height))

    def load_max_score(self):
        try:
            with open("records.json", "r") as f:
                records = json.load(f)
                return records.get("max_score", 0)
        except (FileNotFoundError, json.JSONDecodeError):
            return 0

    def load_food_count(self):
        try:
            with open("settings.json", "r") as f:
                settings = json.load(f)
                return settings.get("food_count", 1)
        except (FileNotFoundError, json.JSONDecodeError):
            return 1

    def back_to_menu(self):
        self.root.destroy()
        root = tk.Tk()
        self.set_fullscreen_root(root)
        menu = GameMenu(root)
        root.mainloop()
    
    def set_fullscreen_root(self, root):
        root.state('zoomed') if sys.platform == "win32" else root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")

class SettingsMenu:
    def __init__(self, root, game_menu):
        self.root = root
        self.root.title("-________________-{Настройки}-________________-")
        self.set_fullscreen()
        self.game_menu = game_menu

        labels = ["____-Скорость змейки", "____-Скорость врага", "____-Скорость генерации яблок", "____-Количество яблок"]
        scales = ["speed", "enemy_speed", "food_speed", "food_count"]
        commands = [self.update_speed, self.update_enemy_speed, self.update_food_speed, self.update_food_count]
        values = [game_menu.speed, game_menu.enemy_speed, game_menu.food_speed, game_menu.food_count]
        mins = [50, 50, 50, 1]
        maxs = [200, 200, 200, 10]

        self.label = tk.Label(root, text="-________-{Настройки}-________-", font=("monospace", 12))
        self.label.pack(pady=20)

        for i, label_text in enumerate(labels):
            label = tk.Label(root, text=label_text, font=("monospace", 10))
            label.pack(pady=5)
            scale = tk.Scale(root, from_=mins[i], to=maxs[i], orient=tk.HORIZONTAL, command=commands[i])
            scale.set(values[i])
            scale.pack(pady=5)
            setattr(self, f"{scales[i]}_scale", scale)
        #Создаем виджет для выбора цвета
        self.grass_colors_label = tk.Label(root, text="____-Цвета травы (RGB, через запятую)", font=("monospace", 10))
        self.grass_colors_label.pack(pady=5)
        self.grass_colors_entry = tk.Entry(root)
        self.grass_colors_entry.insert(0, str(self.game_menu.grass_colors))  # Отображаем текущие цвета
        self.grass_colors_entry.pack(pady=5)

        # Text entry для количества врагов
        self.enemy_count_label = tk.Label(root, text="____-Количество врагов", font=("monospace", 10))
        self.enemy_count_label.pack(pady=5)
        self.enemy_count_entry = tk.Entry(root)
        self.enemy_count_entry.insert(0, str(self.game_menu.enemy_count))
        self.enemy_count_entry.pack(pady=5)

        # Text entry для количества камней
        self.rock_count_label = tk.Label(root, text="____-Количество камней", font=("monospace", 10))
        self.rock_count_label.pack(pady=5)
        self.rock_count_entry = tk.Entry(root)
        self.rock_count_entry.insert(0, str(self.game_menu.rock_count))
        self.rock_count_entry.pack(pady=5)

        # Button для выбора цвета змейки
        self.snake_color_label = tk.Label(root, text="____-Цвет змейки", font=("monospace", 10))
        self.snake_color_label.pack(pady=5)
        self.snake_color_button = tk.Button(root, text="____-Выбрать цвет", command=self.choose_snake_color)
        self.snake_color_button.pack(pady=5)
        self.snake_color_display = tk.Label(root, text=self.game_menu.snake_color, bg=self.game_menu.snake_color, width=10)
        self.snake_color_display.pack(pady=5)

        self.back_button = tk.Button(root, text="-____{Вернуться в меню}____-", command=self.back_to_menu)
        self.back_button.pack(pady=10)
    
    def set_fullscreen(self):
        if sys.platform == "win32":
            self.root.state('zoomed')  # Полноэкранный режим на Windows
        else:
            # Для других систем (Linux, MacOS) пытаемся получить размер экрана
            width = self.root.winfo_screenwidth()
            height = self.root.winfo_screenheight()
            self.root.geometry("%dx%d" % (width, height))

    def choose_snake_color(self):
        color_code = colorchooser.askcolor(title="-____-{Выберите цвет змейки}-____-")[1]
        if color_code:
            self.game_menu.snake_color = color_code
            self.snake_color_display.config(text=color_code, bg=color_code)

    def update_speed(self, value):
        self.game_menu.speed = int(value)

    def update_enemy_speed(self, value):
        self.game_menu.enemy_speed = int(value)

    def update_food_speed(self, value):
        self.game_menu.food_speed = int(value)

    def update_food_count(self, value):
        self.game_menu.food_count = int(value)

    def back_to_menu(self):
        self.save_settings()
        self.root.destroy()
        root = tk.Tk()
        self.set_fullscreen_root(root)
        menu = GameMenu(root)
        root.mainloop()

    def save_settings(self):
       try:
           # Получаем текст из поля ввода и преобразуем в список списков целых чисел
           grass_colors_str = self.grass_colors_entry.get()
           grass_colors = eval(grass_colors_str)  # Используйте eval() ОСТОРОЖНО!

           # Проверяем, что цвета являются списками RGB и значения находятся в диапазоне 0-255
           valid_colors = []
           for color in grass_colors:
               if isinstance(color, list) and len(color) == 3:
                   r, g, b = color
                   if all(isinstance(c, int) and 0 <= c <= 255 for c in [r, g, b]):
                       valid_colors.append([r, g, b])

           if not valid_colors:
               print("Ошибка: некорректные цвета травы. Используются значения по умолчанию.")
               valid_colors = self.game_menu.default_grass_colors  # Возврат к значениям по умолчанию

       except Exception as e:
           print(f"Ошибка при обработке цветов травы: {e}. Используются значения по умолчанию.")
           valid_colors = self.game_menu.default_grass_colors  # В случае любой ошибки - возврат к значениям по умолчанию

       try:
           enemy_count = int(self.enemy_count_entry.get())
           if not 0 <= enemy_count <= 4444444444:
               print("Ошибка: некорректное количество врагов. Используется значение по умолчанию.")
               enemy_count = 3
       except ValueError:
           print("Ошибка: некорректный формат количества врагов. Используется значение по умолчанию.")
           enemy_count = 3

       try:
           rock_count = int(self.rock_count_entry.get())
           if not 0 <= rock_count <= 4444444444:
               print("Ошибка: некорректное количество камней. Используется значение по умолчанию.")
               rock_count = 5
       except ValueError:
           print("Ошибка: некорректный формат количества камней. Используется значение по умолчанию.")
           rock_count = 5

       settings = {
           "speed": self.game_menu.speed,
           "enemy_speed": self.game_menu.enemy_speed,
           "food_speed": self.game_menu.food_speed,
           "food_count": self.game_menu.food_count,
           "grass_colors": valid_colors,
           "snake_color": self.game_menu.snake_color,
           "enemy_count": enemy_count,
           "rock_count": rock_count
       }

       try:
           with open("settings.json", "w") as f:
               json.dump(settings, f)
       except OSError as e:
           print(f"Ошибка сохранения настроек: {e}")

       # Обновляем значения в GameMenu
       self.game_menu.enemy_count = enemy_count
       self.game_menu.rock_count = rock_count

    
    def set_fullscreen_root(self, root):
        root.state('zoomed') if sys.platform == "win32" else root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}")

if __name__ == "__main__":
    root = tk.Tk()
    if sys.platform == "win32":
        root.state('zoomed')  # Полноэкранный режим на Windows
    else:
        # Для других систем (Linux, MacOS) пытаемся получить размер экрана
        width = root.winfo_screenwidth()
        height = root.winfo_screenheight()
        root.geometry("%dx%d" % (width, height))

    menu = GameMenu(root)
    root.mainloop()