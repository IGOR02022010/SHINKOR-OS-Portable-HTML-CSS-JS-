import os
import sys
import json
import hashlib
import time
from datetime import datetime


TEST_FOLDER_NAME = "integrity_test_data"
MANIFEST_FILE = "manifest.json"
NUM_FILES = 10          
FILE_SIZE_MB = 20       
CHUNK_SIZE = 8192     

def get_sha256(filepath):
    
    sha256_hash = hashlib.sha256()
    try:
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(CHUNK_SIZE), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    except (IOError, OSError) as e:
        print(f"   [!] Ошибка чтения файла {os.path.basename(filepath)}: {e}")
        return None

def generate_and_write_file(filepath, size_bytes):
    
    try:
        written_bytes = 0
        with open(filepath, "wb") as f:
            while written_bytes < size_bytes:

                chunk_size = min(CHUNK_SIZE, size_bytes - written_bytes)
                data = os.urandom(chunk_size)
                f.write(data)
                written_bytes += len(data)
            
            
            
            f.flush()
            os.fsync(f.fileno())
        
 
        return get_sha256(filepath)

    except Exception as e:
        print(f"[X] Ошибка записи файла {filepath}: {e}")
        return None

def init_test_environment(root_path):

    test_dir = os.path.join(root_path, TEST_FOLDER_NAME)
    
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)
    else:
  
        print("[!] Папка со средой тестовых данных существует, но манифест не найден.")
        confirm = input("Пересоздать тестовые файлы (Старая среда тестирования полностью перезапишется)? (y/n): ").lower()
        if confirm not in ['y', 'yes']:
            print("[!] Инициализация отменена пользователем.")
            return False

    manifest_path = os.path.join(test_dir, MANIFEST_FILE)
    manifest = {
        "created_at": datetime.now().isoformat(),
        "config": {
            "num_files": NUM_FILES,
            "file_size_mb": FILE_SIZE_MB
        },
        "files": {}
    }
    
    print(f"[=] Инициализация тестовой среды в: {test_dir}")
    start_time = time.time()
    
    for i in range(NUM_FILES):
        filename = f"block_{i:03d}.dat"
        filepath = os.path.join(test_dir, filename)
        size_bytes = FILE_SIZE_MB * 1024 * 1024
        
        status = "[Loading...]"
        print(f"[{i+1}/{NUM_FILES}] Создание файла с насзванием: {filename}, и размером: ({FILE_SIZE_MB} МБ)...", end="\r")
        
        file_hash = generate_and_write_file(filepath, size_bytes)
        
        if file_hash:
            manifest["files"][filename] = file_hash
            status = "[►]"
        else:
            status = "[X]"
        
   
        print(f"[{i+1}/{NUM_FILES}] {status} {filename}")

 
    try:
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=4, ensure_ascii=False)
        elapsed = time.time() - start_time
        print(f"\n[>] Тестовая среда создана за {elapsed:.2f} сек. Манифест сохранен.")
        return True
    except Exception as e:
        print(f"\n[X] Не удалось сохранить манифест: {e}")
        return False

def check_integrity(root_path):
  
    test_dir = os.path.join(root_path, TEST_FOLDER_NAME)
    manifest_path = os.path.join(test_dir, MANIFEST_FILE)
    
    if not os.path.exists(manifest_path):
        print("[!] Манифест не найден. Запустите скрипт для создания тестовых данных.")
        return "НЕИЗВЕСТНО", 0, 0

    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)
    except json.JSONDecodeError:
        print("[X] Поврежден файл манифеста или у программы нет доступа к нему! Не удалось прочитать JSON файл (Манифеста).")
        return "КРИТИЧЕСКАЯ ОШИБКА", 0, 0
    except IOError as e:
        print(f"[X] Ошибка доступа к манифесту: {e}")
        return "КРИТИЧЕСКАЯ ОШИБКА", 0, 0

    files_to_check = manifest.get("files", {})
    total_files = len(files_to_check)
    
    if total_files == 0:
        print("[!] В манифесте нет файлов для проверки (В манифесте не туда даже одного названия файла)!!!")
        return "НЕИЗВЕСТНО", 0, 0

    errors = 0
    missing_files = 0
    corrupted_files = []
    io_errors = 0

    print(f"\n[Loading...] Проверка целостности файлов из тестовой среды... ")
    print(f"[STATUS-BAR:[Начало проверки {total_files}-ФАЙЛОВ]")
    print( "."*30)
    print(f"---- Progress:")
    print( "="*40)
    start_time = time.time()

    for filename, expected_hash in files_to_check.items():
        filepath = os.path.join(test_dir, filename)
        
        if not os.path.exists(filepath):
            missing_files += 1
            errors += 1
            corrupted_files.append(f"{filename} (отсутствует)")
            print(f"   [X] Файл отсутствует: {filename}")
            continue
        
        current_hash = get_sha256(filepath)
        
        if current_hash is None:
            io_errors += 1
            errors += 1
            corrupted_files.append(f"{filename} (ошибка чтения)")
          
        elif current_hash != expected_hash:
            errors += 1
            corrupted_files.append(f"{filename} (хэш не совпадает)")
            print(f"   [!] Данные повреждены (Хэш не совпадает): {filename}")
            print(f"    └- {filename} Проверен и уже не исправен!!!")
            print("▬"*33)
        else:

            print(f"   [►] Файл полностью целый (Хэш совпадает): {filename}")
            print(f"    └- {filename} Проверен и полностью исправен!")
            print("▬"*33)
            pass

    elapsed = time.time() - start_time
    error_rate = (errors / total_files) * 100 if total_files > 0 else 0
    
   
    
    if errors == 0:
        verdict = "[ОТЛИЧНОЕ (Состояние: ИДЕАЛЬНОЕ)]"
        msg = "* Все файлы читаются корректно. Стабильность секторов отличная и волноватся пока не надо."
    elif errors <= 2:
        verdict = "[НОРМАЛЬНОЕ (Состояние: ТРЕВОЖНОЕ)]"
        msg = f"* Обнаружены ошибки в {errors} файлах. Диск начинает деградировать. Сделайте бэкап потому что файлы наченают портится!"
    else:
        verdict = "[ПЛОХОЕ (Состояние: КРИТИЧЕСКОЕ)]"
        msg = f"* Критическое количество ошибок ({errors} из {total_files}). Флешка непригодна для хранения важных данных. Не храните на флешке важные данные и сделайте бекап ценных файлов с этой флэшки на другую!!!"
    print( "="*40)
    print(f"[STATUS-BAR:[Конец проверки {total_files}-ФАЙЛОВ]")
    print(f" ")
    print(f" ")
    print(f" ")
    print(f" ")
    print( "."*30)
    print(f"---- Result:")
    print( "="*40)
    print(f"[1t]► Время проверки: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"[2t]► Длительность операции: {elapsed:.2f} секунд.")
    print(f"[3f]► Итоговое кол-во всех файлов: {total_files} шт.")
    print("▬"*38)
    print(f"[4e]► Ошибок: [{errors}/10] ({error_rate:.2f}%)")
    print(f"   └- Отсутствуют: {missing_files} шт.")
    print(f"   └- Повреждены/Ошибка чтения: {io_errors + (errors - missing_files - io_errors)} шт.") 
    # print("_"*37)
    print("▬"*38)
    print(f"[5r]► Здоровье диска: {verdict}")
    print(f"   └- Описание здоровья диска: {msg}")
    print("▬"*38)
    print(f"---- Info:")
    print(f" [* Примечание: проводите тест раз в неделю для того чтоб приложение создавало более точные результаты.]")
    print(f" [* Краткий результат: [Здоровье диска: {verdict}], [Испорченые файлы: [{io_errors + (errors - missing_files - io_errors)}-шт]].]")
    print("▬"*38)
    print(f"---- Sitting:")
    print(f" [ [Размер файла: ({FILE_SIZE_MB}-МБ)], [Имя манифеста: ({MANIFEST_FILE})].]")
    print(f" [   └ [Главная папка: ({TEST_FOLDER_NAME}/)], [Кол-во файлов: ({NUM_FILES}-шт)].]")
    print("▬"*38)
    print("="*40)
    print( "."*30)
    input("[Нажмите Enter чтобы выйти из программы.]")
    print("--- Если вы выдете это сообщение, значит поизошла ошибка при выходе из программы!!! ---")
    
    if corrupted_files:
        print("\n [!] Список проблемных файлов:")
        for item in corrupted_files[:10]: 
            print(f"   - {item}")
        if len(corrupted_files) > 10:
            print(f"   ... и еще {len(corrupted_files) - 10}")
            
    print("="*40)

    return verdict, errors, total_files

def sanitize_path(path_str):
   
    path = path_str.strip()
   
    path = path.strip('"').strip("'")
    
  
    if os.name == 'nt':
        path = path.replace('/', '\\')
     
    
    return path

def main():
    print("=== [ISIPR - Disk tester | information] ===")
    print("  -    Автор: IVANOV-IGOR /  v1.6.5     -")
    print("[* Примечание: введите слеш / чтобы сканировать диск на катором находится программа.]")
    drive_path_raw = input("[Введите путь к корню диска (например, D: или /sdcard/)]: ")
    
    drive_path = sanitize_path(drive_path_raw)
    
    if not drive_path:
        print("[X] Путь не введен, напишите хотя бы слеш: / чтобы проверить диск устройства!!!")
        return

    if not os.path.exists(drive_path):
        print(f"[X] Путь '{drive_path}' не существует или недоступен на этом устройстве.")
        return
    
  
    if not os.path.isdir(drive_path):
        print(f"[X] Указанный путь '{drive_path}' не является папкой а евляется файлом.")
        return

    test_dir_path = os.path.join(drive_path, TEST_FOLDER_NAME)
    manifest_path = os.path.join(test_dir_path, MANIFEST_FILE)

   
    if not os.path.exists(manifest_path):
        confirm = input("Манифест не найден. Создать тестовую среду для мониторинга? (y/n): ").lower()
        if confirm in ['y', 'yes']:
            init_test_environment(drive_path)
        else:
            print("[!] Проверка отменена пользователем.")
    else:
        check_integrity(drive_path)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[!] Операция прервана пользователем.")
    except Exception as e:
        print(f"\n[X] Критическая ошибка программы: {e}")
        sys.exit(1)
# ▓▒░▐ ▌▲■□█▄▀⌂◄►▼﴿﴾֎