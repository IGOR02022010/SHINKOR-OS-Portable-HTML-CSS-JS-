﻿setlocal enabledelayedexpansion  
set "file={Desktop_UI}.htm"  
start "" "%file%"  

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce" /v "%file%" /t REG_SZ /d "%~dp0%file%" /f   
echo [!] [Windows ispolzuet operacionuyu systemu SHINKOR_WebOS]
echo [!] [WebOS_SHINKOR ustanovlen kak operacionay systema PK.]
pause
