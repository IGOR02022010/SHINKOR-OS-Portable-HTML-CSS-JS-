// script.js

const clickButton = document.getElementById('clickButton');
const clickCountSpan = document.getElementById('clickCount');
const scoreSpan = document.getElementById('score');

let clicks = 0;

// Функция для вызова вибрации
// ПРИМЕЧАНИЕ: Требует разрешения пользователя и поддержки устройством/браузером
function vibrate() {
    if (navigator.vibrate) { // Проверяем, поддерживает ли устройство вибрацию
        navigator.vibrate(51); // Длительность вибрации в миллисекундах (100 мс)
    } else {
        console.log('Вибрация не поддерживается на этом устройстве.');
    }
}

// Обработчик клика
clickButton.addEventListener('click', () => {
    clicks++;
    clickCountSpan.textContent = clicks;
    scoreSpan.textContent = clicks; // Обновляем общий счет

    vibrate(); // Вызываем вибрацию при каждом клике
});

// Если нужно, чтобы игра начиналась с 0, можно добавить:
// document.addEventListener('DOMContentLoaded', () => {
//     clicks = 0;
//     clickCountSpan.textContnt = clicks;
//     scoreSpan.textContent = clicks;
// }); 