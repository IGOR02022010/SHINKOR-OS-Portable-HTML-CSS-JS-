﻿setlocal enabledelayedexpansion  
set "file=.[System_UI]/{LookScreen}.htm"  
start "" "%file%"  

